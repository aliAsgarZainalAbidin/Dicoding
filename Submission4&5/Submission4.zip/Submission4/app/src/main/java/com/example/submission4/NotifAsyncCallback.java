package com.example.submission4;

public interface NotifAsyncCallback {
    void preAsync();
    void postAsync();
}
